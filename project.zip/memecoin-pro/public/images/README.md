# QR Code Images

This directory contains QR code images for the mock payment system:

- btc-qr.png - Bitcoin payment QR code
- eth-qr.png - Ethereum payment QR code 
- usdt-qr.png - Tether payment QR code

The QR codes are non-functional and for display purposes only as part of the honeypot decoy site.
